# Links

Website : [cosmosdao.org](https://cosmosdao.org/)

Dex :&#x20;

Smart contract:&#x20;

**Community**

X : [https://x.com/CosmosdaoRWA](https://x.com/CosmosdaoRWA)

Telegram :&#x20;

